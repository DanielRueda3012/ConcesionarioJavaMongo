package hilos;

import view.VentanaLogin;

public class MensajeRegistrado extends Thread {

	@Override
	public void run() {
		String mensaje = "Usuario registrado con éxito";
		VentanaLogin.labelConfirmacion.setText(mensaje);
		VentanaLogin.labelConfirmacion.setVisible(true);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		VentanaLogin.labelConfirmacion.setVisible(false);
	}

}
