package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Random;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Projections;

import bd.MongoDB;
import controller.Gestion;
import dao.VehiculosDAO;

public class VentanaStock extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JList<String> listStock;
    private DefaultListModel<String> listModel;
    private JScrollPane scrollPane;
    private JButton btnComprar;
    private JButton btnAtras;
    private Gestion g;
    private VehiculosDAO v;

    public VentanaStock(Gestion g, VehiculosDAO v) {
        this.g = g;
        this.v = v;

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // Evita que se cierre la ventana directamente
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose(); // Cierra la ventana actual al hacer clic en la cruz roja
            }
        });

        setBounds(100, 100, 450, 400);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblStockTitle = new JLabel("Lista de Vehículos y Stock");
        lblStockTitle.setBackground(Color.ORANGE);
        lblStockTitle.setFont(new Font("Arial", Font.BOLD, 20));
        lblStockTitle.setHorizontalAlignment(JLabel.CENTER);
        lblStockTitle.setBounds(10, 11, 414, 30);
        contentPane.add(lblStockTitle);

        listModel = new DefaultListModel<>();
        listStock = new JList<>(listModel);
        listStock.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listStock.setFont(new Font("Arial", Font.PLAIN, 14));

        scrollPane = new JScrollPane(listStock);
        scrollPane.setBounds(10, 52, 414, 170);
        contentPane.add(scrollPane);

        btnComprar = new JButton("Comprar");
        btnComprar.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnComprar.setBackground(Color.LIGHT_GRAY);
        btnComprar.setForeground(Color.BLACK);
        btnComprar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                comprarVehiculo();
            }
        });
        btnComprar.setBounds(95, 250, 120, 40);
        contentPane.add(btnComprar);

        btnAtras = new JButton("Atrás");
        btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnAtras.setBackground(Color.LIGHT_GRAY);
        btnAtras.setForeground(Color.BLACK);
        btnAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                volverMenuPrincipal();
            }
        });
        btnAtras.setBounds(245, 250, 120, 40);
        contentPane.add(btnAtras);

        actualizarStock();
    }

    private void actualizarStock() {
        // Obtener los datos de la base de datos MongoDB
        MongoDatabase db = MongoDB.getClient().getDatabase("proyecto_concesionario");
        MongoCollection<Document> collection = db.getCollection("vehiculos");

        // Proyectar solo los campos de nombre y modelo
        MongoCursor<Document> cursor = collection.find()
                .projection(Projections.fields(Projections.include("marca", "modelo"))).iterator();

        // Limpiar el modelo de lista
        listModel.clear();

        // Agregar cada vehículo y su stock aleatorio al modelo de lista
        Random random = new Random();
        while (cursor.hasNext()) {
            Document doc = cursor.next();
            String nombre = doc.getString("marca");
            String modelo = doc.getString("modelo");
            int stock = random.nextInt(11); // Genera un stock aleatorio entre 0 y 10 inclusive
            listModel.addElement(nombre + " - " + modelo + " : " + stock);
        }

        // Cerrar el cursor
        cursor.close();
    }

    private void comprarVehiculo() {
        // Lógica para comprar un vehículo
        // Implementa la lógica de compra aquí
    }

    private void volverMenuPrincipal() {
        dispose(); // Cierra la ventana actual
        VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(this.g, this.v);
        ventanaPrincipal.setVisible(true);
    }
}
