package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Gestion;
import dao.UsersDAO;
import dao.VehiculosDAO;
import eventos.LoginEvent;

public class VentanaLogin extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    public static JPanel panelBienvenida;
    public static JPanel panelInicioSesion;
    public static JPanel panelRegistro;
    public static VentanaLogin frame;
    public static JTextField txtUsuario;
    public static JPasswordField txtPassword;
    public static JTextField txtNombreReg;
    public static JTextField txtApellidosReg;
    public static JTextField txtCorreoReg;
    public static JTextField txtUsuarioReg;
    public static JTextField txtPasswordReg;
    public static JButton buttonIniciarSesion;
    public static JButton buttonRegistrate;
    public static JButton buttonRegistrarse;
    public static JButton buttonAtrasReg;
    public static JButton buttonAcceder;
    public static JButton buttonAtras;
    public static JLabel labelConfirmacion;
    public static JLabel lblMensajeErrorReg;
    public static JLabel lblMensajeError;

    public VentanaLogin(Gestion g, VehiculosDAO vd, UsersDAO ud) {
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 630, 400);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel labelTitulo = new JLabel("AUTOS.COM");
        labelTitulo.setOpaque(true);
        labelTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        labelTitulo.setForeground(Color.WHITE);
        labelTitulo.setFont(new Font("Tahoma", Font.BOLD, 30));
        labelTitulo.setBackground(new Color(255, 128, 0));
        labelTitulo.setBounds(0, 0, 616, 49);
        contentPane.add(labelTitulo);

        panelRegistro = new JPanel();
        panelRegistro.setVisible(false);
        panelRegistro.setBounds(161, 49, 455, 316);
        contentPane.add(panelRegistro);
        panelRegistro.setLayout(null);
        panelRegistro.setBackground(Color.WHITE);

        JLabel labelApellidosReg = new JLabel("Apellidos");
        labelApellidosReg.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelApellidosReg.setBounds(38, 95, 89, 15);
        panelRegistro.add(labelApellidosReg);

        txtNombreReg = new JTextField();
        txtNombreReg.setForeground(new Color(0, 0, 0));
        txtNombreReg.setFont(new Font("Tahoma", Font.PLAIN, 13));
        txtNombreReg.setColumns(10);
        txtNombreReg.setBounds(204, 55, 211, 16);
        panelRegistro.add(txtNombreReg);

        JLabel labelNombreReg = new JLabel("Nombre");
        labelNombreReg.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelNombreReg.setBounds(38, 55, 79, 15);
        panelRegistro.add(labelNombreReg);

        buttonRegistrarse = new JButton("REGISTRARSE");
        buttonRegistrarse.setForeground(Color.WHITE);
        buttonRegistrarse.setFont(new Font("Tahoma", Font.BOLD, 15));
        buttonRegistrarse.setBackground(new Color(255, 128, 0));
        buttonRegistrarse.setBounds(206, 275, 150, 31);
        panelRegistro.add(buttonRegistrarse);
        buttonRegistrarse.addActionListener(new LoginEvent(g, vd, ud));

        JLabel lblRegistrate = new JLabel("REGÍSTRATE");
        lblRegistrate.setForeground(new Color(255, 128, 0));
        lblRegistrate.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblRegistrate.setBounds(38, 10, 182, 22);
        panelRegistro.add(lblRegistrate);

        JLabel labelCorreoReg = new JLabel("Correo electrónico");
        labelCorreoReg.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelCorreoReg.setBounds(38, 135, 156, 15);
        panelRegistro.add(labelCorreoReg);

        JLabel labelUsuarioReg = new JLabel("Usuario");
        labelUsuarioReg.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelUsuarioReg.setBounds(38, 175, 79, 15);
        panelRegistro.add(labelUsuarioReg);

        JLabel lblContrasenaReg = new JLabel("Contraseña");
        lblContrasenaReg.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblContrasenaReg.setBounds(38, 215, 156, 15);
        panelRegistro.add(lblContrasenaReg);

        txtApellidosReg = new JTextField();
        txtApellidosReg.setForeground(Color.BLACK);
        txtApellidosReg.setFont(new Font("Tahoma", Font.PLAIN, 13));
        txtApellidosReg.setColumns(10);
        txtApellidosReg.setBounds(204, 95, 211, 16);
        panelRegistro.add(txtApellidosReg);

        txtCorreoReg = new JTextField();
        txtCorreoReg.setForeground(Color.BLACK);
        txtCorreoReg.setFont(new Font("Tahoma", Font.PLAIN, 13));
        txtCorreoReg.setColumns(10);
        txtCorreoReg.setBounds(204, 135, 211, 16);
        panelRegistro.add(txtCorreoReg);

        txtUsuarioReg = new JTextField();
        txtUsuarioReg.setForeground(Color.BLACK);
        txtUsuarioReg.setFont(new Font("Tahoma", Font.PLAIN, 13));
        txtUsuarioReg.setColumns(10);
        txtUsuarioReg.setBounds(204, 175, 211, 16);
        panelRegistro.add(txtUsuarioReg);

        txtPasswordReg = new JPasswordField();
        txtPasswordReg.setForeground(Color.BLACK);
        txtPasswordReg.setFont(new Font("Tahoma", Font.PLAIN, 13));
        txtPasswordReg.setColumns(10);
        txtPasswordReg.setBounds(204, 215, 211, 16);
        panelRegistro.add(txtPasswordReg);

        buttonAtrasReg = new JButton("ATRÁS");
        buttonAtrasReg.setForeground(Color.WHITE);
        buttonAtrasReg.setFont(new Font("Tahoma", Font.BOLD, 15));
        buttonAtrasReg.setBackground(new Color(255, 128, 0));
        buttonAtrasReg.setBounds(99, 275, 95, 31);
        panelRegistro.add(buttonAtrasReg);

        lblMensajeErrorReg = new JLabel("");
        lblMensajeErrorReg.setForeground(new Color(255, 0, 0));
        lblMensajeErrorReg.setHorizontalAlignment(SwingConstants.CENTER);
        lblMensajeErrorReg.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblMensajeErrorReg.setBounds(38, 246, 377, 13);
        panelRegistro.add(lblMensajeErrorReg);
        buttonAtrasReg.addActionListener(new LoginEvent(g, vd, ud));

        panelBienvenida = new JPanel();
        panelBienvenida.setBackground(new Color(255, 255, 255));
        panelBienvenida.setBounds(161, 49, 455, 316);
        contentPane.add(panelBienvenida);
        panelBienvenida.setLayout(null);

        JLabel lblBienvenida = new JLabel("¡BIENVENIDO!");
        lblBienvenida.setBounds(134, 26, 166, 27);
        lblBienvenida.setForeground(new Color(255, 128, 0));
        lblBienvenida.setFont(new Font("Tahoma", Font.BOLD, 22));
        panelBienvenida.add(lblBienvenida);

        buttonIniciarSesion = new JButton("Iniciar sesión");
        buttonIniciarSesion.setForeground(new Color(255, 255, 255));
        buttonIniciarSesion.setBackground(new Color(255, 128, 0));
        buttonIniciarSesion.setFont(new Font("Tahoma", Font.BOLD, 15));
        buttonIniciarSesion.setBounds(145, 98, 143, 30);
        panelBienvenida.add(buttonIniciarSesion);
        buttonIniciarSesion.addActionListener(new LoginEvent(g, vd, ud));

        buttonRegistrate = new JButton("Regístrarse");
        buttonRegistrate.setForeground(new Color(255, 255, 255));
        buttonRegistrate.setBackground(new Color(255, 128, 0));
        buttonRegistrate.setFont(new Font("Tahoma", Font.BOLD, 15));
        buttonRegistrate.setBounds(145, 161, 143, 30);
        panelBienvenida.add(buttonRegistrate);

        labelConfirmacion = new JLabel("");
        labelConfirmacion.setVisible(false);
        labelConfirmacion.setForeground(new Color(27, 198, 17));
        labelConfirmacion.setHorizontalAlignment(SwingConstants.CENTER);
        labelConfirmacion.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelConfirmacion.setBounds(22, 257, 387, 21);
        panelBienvenida.add(labelConfirmacion);
        buttonRegistrate.addActionListener(new LoginEvent(g, vd, ud));

        JPanel panelLogo = new JPanel();
        panelLogo.setBackground(new Color(255, 128, 0));
        panelLogo.setBounds(0, 47, 161, 316);
        contentPane.add(panelLogo);
        panelLogo.setLayout(null);

        String rutaIconoOriginal = "src/main/java/view/IconoCoche.png";
        Icon iconoReducido = escalarIcono(new ImageIcon(rutaIconoOriginal), 100, 100);

        JLabel labelIcono = new JLabel("");
        labelIcono.setIcon(iconoReducido);
        labelIcono.setBounds(10, 15, 141, 114);
        panelLogo.add(labelIcono);

        JLabel labelDaniel = new JLabel("Daniel Rueda");
        labelDaniel.setHorizontalAlignment(SwingConstants.LEFT);
        labelDaniel.setForeground(new Color(255, 255, 255));
        labelDaniel.setFont(new Font("Tahoma", Font.BOLD, 14));
        labelDaniel.setBounds(10, 207, 141, 13);
        panelLogo.add(labelDaniel);

        JLabel labelAlvaro = new JLabel("Álvaro Márquez");
        labelAlvaro.setHorizontalAlignment(SwingConstants.LEFT);
        labelAlvaro.setForeground(Color.WHITE);
        labelAlvaro.setFont(new Font("Tahoma", Font.BOLD, 14));
        labelAlvaro.setBounds(10, 230, 141, 13);
        panelLogo.add(labelAlvaro);

        JLabel labelContacto = new JLabel("cars@autos.com");
        labelContacto.setHorizontalAlignment(SwingConstants.LEFT);
        labelContacto.setForeground(Color.WHITE);
        labelContacto.setFont(new Font("Tahoma", Font.BOLD, 14));
        labelContacto.setBounds(10, 253, 141, 13);
        panelLogo.add(labelContacto);

        JLabel labelContactoMovil = new JLabel("(+34) 999-999-999");
        labelContactoMovil.setHorizontalAlignment(SwingConstants.LEFT);
        labelContactoMovil.setForeground(Color.WHITE);
        labelContactoMovil.setFont(new Font("Tahoma", Font.BOLD, 14));
        labelContactoMovil.setBounds(10, 276, 141, 13);
        panelLogo.add(labelContactoMovil);

        JLabel labelAchraf = new JLabel("Achraf Boujaanan");
        labelAchraf.setHorizontalAlignment(SwingConstants.LEFT);
        labelAchraf.setForeground(Color.WHITE);
        labelAchraf.setFont(new Font("Tahoma", Font.BOLD, 14));
        labelAchraf.setBounds(10, 184, 141, 13);
        panelLogo.add(labelAchraf);

        panelInicioSesion = new JPanel();
        panelInicioSesion.setBounds(161, 49, 455, 316);
        contentPane.add(panelInicioSesion);
        panelInicioSesion.setBackground(new Color(255, 255, 255));
        panelInicioSesion.setLayout(null);

        JLabel lblContrasea = new JLabel("Contraseña");
        lblContrasea.setBounds(80, 165, 102, 13);
        panelInicioSesion.add(lblContrasea);
        lblContrasea.setFont(new Font("Tahoma", Font.BOLD, 16));

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
        txtPassword.setForeground(new Color(192, 192, 192));
        txtPassword.setBounds(80, 185, 290, 19);
        panelInicioSesion.add(txtPassword);
        txtPassword.setBorder(null);

        JLabel labelLinea2 = new JLabel("______________________________________________");
        labelLinea2.setBounds(80, 198, 303, 13);
        panelInicioSesion.add(labelLinea2);
        labelLinea2.setFont(new Font("Tahoma", Font.BOLD, 10));

        txtUsuario = new JTextField();
        txtUsuario.setForeground(new Color(192, 192, 192));
        txtUsuario.setBounds(80, 100, 290, 19);
        panelInicioSesion.add(txtUsuario);
        txtUsuario.setBorder(null);
        txtUsuario.setFont(new Font("Tahoma", Font.BOLD, 15));
        txtUsuario.setColumns(10);

        JLabel labelLinea = new JLabel("______________________________________________");
        labelLinea.setBounds(80, 113, 303, 13);
        panelInicioSesion.add(labelLinea);
        labelLinea.setFont(new Font("Tahoma", Font.BOLD, 10));

        JLabel labelUsuario = new JLabel("Usuario");
        labelUsuario.setBounds(80, 80, 79, 13);
        panelInicioSesion.add(labelUsuario);
        labelUsuario.setFont(new Font("Tahoma", Font.BOLD, 16));

        buttonAcceder = new JButton("ACCEDER");
        buttonAcceder.setBounds(212, 264, 120, 31);
        panelInicioSesion.add(buttonAcceder);
        buttonAcceder.setBackground(new Color(255, 128, 0));
        buttonAcceder.setForeground(new Color(255, 255, 255));
        buttonAcceder.setFont(new Font("Tahoma", Font.BOLD, 15));
        panelInicioSesion.add(buttonAcceder);
        buttonAcceder.addActionListener(new LoginEvent(g, vd, ud));

        JLabel lblInicioSesion = new JLabel("INICIO SESIÓN");
        lblInicioSesion.setForeground(new Color(255, 128, 0));
        lblInicioSesion.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblInicioSesion.setBounds(80, 26, 182, 22);
        panelInicioSesion.add(lblInicioSesion);

        buttonAtras = new JButton("ATRÁS");
        buttonAtras.setForeground(Color.WHITE);
        buttonAtras.setFont(new Font("Tahoma", Font.BOLD, 15));
        buttonAtras.setBackground(new Color(255, 128, 0));
        buttonAtras.setBounds(107, 264, 95, 31);
        panelInicioSesion.add(buttonAtras);

        lblMensajeError = new JLabel("");
        lblMensajeError.setForeground(new Color(255, 0, 0));
        lblMensajeError.setHorizontalAlignment(SwingConstants.CENTER);
        lblMensajeError.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblMensajeError.setBounds(35, 232, 377, 13);
        panelInicioSesion.add(lblMensajeError);
        buttonAtras.addActionListener(new LoginEvent(g, vd, ud));

        ud.createUsersCollection();
    }

    public static Icon escalarIcono(ImageIcon iconoOriginal, int ancho, int alto) {
        Image imagenOriginal = iconoOriginal.getImage();
        Image imagenEscalada = imagenOriginal.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }
}
