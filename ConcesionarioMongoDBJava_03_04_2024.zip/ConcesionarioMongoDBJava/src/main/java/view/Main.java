package view;

import controller.Gestion;
import dao.UsersDAO;
import dao.VehiculosDAO;

public class Main {
	public static void main(String[] args) {
		try {
			Gestion g = new Gestion();
			VehiculosDAO vhd = new VehiculosDAO();
			UsersDAO ud = new UsersDAO();

			VentanaLogin vl = new VentanaLogin(g, vhd, ud);
			vl.setVisible(true);
		}
		catch (Exception e) {
		}
	}
}