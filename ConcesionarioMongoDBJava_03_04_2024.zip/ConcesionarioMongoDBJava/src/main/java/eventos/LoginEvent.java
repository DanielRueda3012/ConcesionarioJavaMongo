package eventos;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import controller.Gestion;
import dao.UsersDAO;
import dao.VehiculosDAO;
import hilos.MensajeRegistrado;
import view.VentanaLogin;
import view.VentanaPrincipal;

public class LoginEvent implements ActionListener, KeyListener {

	private Gestion g;
	private VehiculosDAO vd;
	private UsersDAO ud;

	public LoginEvent(Gestion g, VehiculosDAO vd, UsersDAO ud) {
		this.g = g;
		this.vd = vd;
		this.ud = ud;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(VentanaLogin.buttonIniciarSesion)) {
			VentanaLogin.panelBienvenida.setVisible(false);
			VentanaLogin.panelInicioSesion.setVisible(true);
		}

		if (e.getSource().equals(VentanaLogin.buttonRegistrate)) {
			VentanaLogin.panelBienvenida.setVisible(false);
			VentanaLogin.panelRegistro.setVisible(true);
		}

		if (e.getSource().equals(VentanaLogin.buttonAtras)) {
			VentanaLogin.panelBienvenida.setVisible(true);
			VentanaLogin.panelInicioSesion.setVisible(false);
			VentanaLogin.txtUsuario.setText("");
			VentanaLogin.txtPassword.setText("");
			VentanaLogin.lblMensajeError.setText(""); // Limpiar el mensaje de error al volver atrás
		}

		if (e.getSource().equals(VentanaLogin.buttonRegistrarse)) {
			if (camposRegistroRellenos()) {
				String nombre = VentanaLogin.txtNombreReg.getText();
				String apellidos = VentanaLogin.txtApellidosReg.getText();
				String correo = VentanaLogin.txtCorreoReg.getText();
				String user = VentanaLogin.txtUsuarioReg.getText();
				String pass = VentanaLogin.txtPasswordReg.getText();

				if (ud.registerUser(nombre, apellidos, correo, user, pass)) {
					MensajeRegistrado mr = new MensajeRegistrado();
					mr.start();

					VentanaLogin.panelBienvenida.setVisible(true);
					VentanaLogin.panelRegistro.setVisible(false);
					vaciarCamposRegistro();
					limpiarTextoError();
				} else {
					VentanaLogin.lblMensajeErrorReg.setText("Error al registrarse");
				}
			} else {
				mensajeCamposVacios();
			}
		}

		if (e.getSource().equals(VentanaLogin.buttonAtrasReg)) {
			VentanaLogin.panelBienvenida.setVisible(true);
			VentanaLogin.panelRegistro.setVisible(false);
			limpiarTextoError(); // Limpiar el mensaje de error al volver atrás
			vaciarCamposRegistro();
		}

		if (e.getSource().equals(VentanaLogin.buttonAcceder)) {
			if (camposInicioSesionRellenos()) {
				String user = VentanaLogin.txtUsuario.getText();
				String pass = new String(VentanaLogin.txtPassword.getPassword()); // Obtener la contraseña correctamente

				if (ud.verifyUser(user, pass)) {
					VentanaPrincipal vp = new VentanaPrincipal(g, vd);
					vp.setVisible(true);
					vp.setModal(true);
					VentanaLogin.txtUsuario.setForeground(Color.BLACK);
					VentanaLogin.txtPassword.setForeground(Color.BLACK);
				} else {
					VentanaLogin.txtUsuario.setForeground(Color.RED);
					VentanaLogin.txtPassword.setForeground(Color.RED);
					VentanaLogin.lblMensajeError.setText("Credenciales incorrectas");
				}
			} else {
				VentanaLogin.lblMensajeError.setText("Introduzca sus credenciales incorrectas");
			}
		}
	}

	private void mensajeCamposVacios() {
		VentanaLogin.lblMensajeError.setText("Por favor, rellena los campos vacíos.");
	}

	private void limpiarTextoError() {
		VentanaLogin.lblMensajeError.setText("");
	}

	private void vaciarCamposRegistro() {
		VentanaLogin.txtNombreReg.setText("");
		VentanaLogin.txtApellidosReg.setText("");
		VentanaLogin.txtCorreoReg.setText("");
		VentanaLogin.txtUsuarioReg.setText("");
		VentanaLogin.txtPasswordReg.setText("");
	}

	private boolean camposRegistroRellenos() {
		return !VentanaLogin.txtNombreReg.getText().isEmpty() && !VentanaLogin.txtApellidosReg.getText().isEmpty()
				&& !VentanaLogin.txtCorreoReg.getText().isEmpty() && !VentanaLogin.txtUsuarioReg.getText().isEmpty()
				&& !VentanaLogin.txtPasswordReg.getText().isEmpty();
	}

	private boolean camposInicioSesionRellenos() {
		return !VentanaLogin.txtUsuario.getText().isEmpty() && VentanaLogin.txtPassword.getPassword().length > 0; // Verificar
																													// si
																													// la
																													// contraseña
																													// no
																													// está
																													// vacía
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// No se necesita implementar en este caso
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// No se necesita implementar en este caso
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
			if (VentanaLogin.txtUsuario.getText().length() == 0 || VentanaLogin.txtPassword.getPassword().length == 0) { // Verificar
																															// la
																															// longitud
																															// de
																															// la
																															// contraseña
				VentanaLogin.txtUsuario.setForeground(Color.BLACK);
				VentanaLogin.txtPassword.setForeground(Color.BLACK);
				VentanaLogin.lblMensajeError.setText("");
			}
		}
	}
}
