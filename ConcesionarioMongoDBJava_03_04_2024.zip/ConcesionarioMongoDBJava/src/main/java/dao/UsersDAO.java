package dao;

import java.util.ArrayList;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Projections;

import bd.MongoDB;

public class UsersDAO {

    private MongoClient mc;
    private MongoDatabase db;

    public UsersDAO() {
        this.mc = MongoDB.getClient();
        this.db = mc.getDatabase("proyecto_concesionario");
    }

    public void createUsersCollection() {
        if (!db.listCollectionNames().into(new ArrayList<>()).contains("usuarios")) {
            db.createCollection("usuarios");
        }
    }

    public boolean verifyUser(String user, String pass) {
        try {
            MongoCollection<Document> collection = db.getCollection("usuarios");
            Document query = new Document("user", user).append("pass", pass);
            Document result = collection.find(query).projection(Projections.fields(Projections.include("user", "pass")))
                    .first();
            return result != null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean userExists(String user) {
        try {
            MongoCollection<Document> collection = db.getCollection("usuarios");
            Document query = new Document("user", user);
            Document result = collection.find(query).projection(Projections.fields(Projections.include("user")))
                    .first();
            return result != null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean correoExists(String correo) {
        try {
            MongoCollection<Document> collection = db.getCollection("usuarios");
            Document query = new Document("correo", correo);
            Document result = collection.find(query).projection(Projections.fields(Projections.include("correo")))
                    .first();
            return result != null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean registerUser(String nombre, String apellidos, String correo, String user, String pass) {
        try {
            MongoCollection<Document> collection = db.getCollection("usuarios");
            Document usuario = new Document("nombre", nombre).append("apellidos", apellidos).append("correo", correo)
                    .append("user", user).append("pass", pass);
            collection.insertOne(usuario);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
